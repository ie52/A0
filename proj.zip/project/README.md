# SoundBridge Pro - Bluetooth Transmitter

A modern landing page for the SoundBridge Pro Bluetooth transmitter, built with React, Vite, and Tailwind CSS.

## Features

- Responsive design
- Modern UI with Tailwind CSS
- Interactive components
- Contact form
- Product showcase
- Under Construction page
- React Router integration

## Getting Started

1. Clone the repository:
```bash
git clone https://github.com/yourusername/soundbridge-pro.git
```

2. Install dependencies:
```bash
cd soundbridge-pro
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## Project Structure

```
soundbridge-pro/
├── public/
│   └── bluetooth.svg
├── src/
│   ├── App.jsx
│   ├── UnderConstruction.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.js
└── tailwind.config.js
```

## Technologies Used

- React 18
- Vite
- Tailwind CSS
- React Router DOM
- Heroicons
- PostCSS

## License

Copyright © 2025 Isaac Etokhana. All rights reserved.